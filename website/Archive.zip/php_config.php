<?php

define('ROOT_PATH', '/');
define('ROOT_URL', 'http://localhost:8888/');
define('DOC_ROOT', $_SERVER['DOCUMENT_ROOT']);

?>
