<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<meta name="description" content="">
<meta name="author" content="">
<link rel="icon" href="../../favicon.ico">


<script src="<?php echo constant('ROOT_URL'); ?>luceole/script/jquery.js">
</script>

<script src="<?php echo constant('ROOT_URL'); ?>luceole/script/js_handler.js">
</script>

<!-- Bootstrap core CSS -->
<!--link href="../../css/bootstrap.min.css" rel="stylesheet"-->
<link href="<?php echo constant('ROOT_URL'); ?>css/bootstrap.min.css" rel="stylesheet">
<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<!-- <link href="../../assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet"> -->

<!-- Custom styles for this template -->
<link href="<?php echo constant('ROOT_URL'); ?>luceole/css/starter-template.css" rel="stylesheet">

<!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
<!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
<!-- <script src="../../assets/js/ie-emulation-modes-warning.js"></script> -->
