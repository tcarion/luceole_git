<link href="http://localhost:8888/luceole/css/starter-template.css" rel="stylesheet">
<div class="container">
  <div class="row">
    <div class="col-lg-4">
      <img src="<?php echo constant('ROOT_URL'); ?>index.php?page=rescoop_logo&mode=html" style="height: 50px; padding-left: 0px; margin-left: 0px;">

      <!--img src="http://localhost:8888/luceole/files/rescoop.png" style="height: 50px; padding-left: 0px; margin-left: 0px;"-->
    </div>
    <!--<div class="col-lg-4">
      <img src="http://localhost:8888/luceole/files/rescoop.png" class="partner-icons">
    </div>
    <div class="col-lg-4">
      <img src="http://localhost:8888/luceole/files/rescoop.png" class="partner-icons">
    </div>-->
  </div>
</div>

<div class="container" style="padding-left: 15px">
  <font color="white">© Lucéole scrl - All rights reserved</font>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
<script src="<?php echo constant('ROOT_URL'); ?>js/bootstrap.min.js"></script>
<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
